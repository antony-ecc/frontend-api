<script setup>
import TheWelcome from '../components/TheWelcome.vue'
</script>

<template>
  <main>
    <h1 class="title">Latest Post</h1>
  </main>
</template>
